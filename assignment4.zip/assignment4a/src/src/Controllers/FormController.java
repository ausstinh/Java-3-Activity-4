package src.Controllers;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;

import business.OrdersBusinessInterface;
import src.Models.User;


@ManagedBean
@ViewScoped
public class FormController {

	@Inject
	OrdersBusinessInterface service;
	
	public String onSubmit(User user) 
	{
		//Call Business Service for testing only and to demo CDI
		service.test();
		//Forward to Test Response View along with the USer Managed Bean
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "TestResponse.xhtml";
	}
	
	public OrdersBusinessInterface getService()
	{
		return service;
	}
}
