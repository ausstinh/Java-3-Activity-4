package business;

import javax.ejb.Schedule;
import javax.ejb.Stateless;
import javax.ejb.Timeout;
import javax.ejb.Timer;
import javax.ejb.TimerService;
import java.util.logging.Logger;

import javax.annotation.Resource;

@Stateless
public class DummyTimer {

	@Resource
	TimerService timerService;
	private static final Logger logger = Logger.getLogger("business.MyTimerService");
    public DummyTimer() {
        
    }
    
    public void setTimer(long interval) {
    	timerService.createTimer(interval,  "Setting a Programmic Timer");
    }
    @Timeout
    public void programmaticTimeout(Timer timer) {
    	logger.info("@Timeout in programmicTimeout called at: " + new java.util.Date());
    }
	
	@Schedule(second="*/60", minute="*", hour="8-23", dayOfWeek="Mon-Fri",
      dayOfMonth="*", month="*", year="*", info="MyTimer")
    private void scheduledTimeout(final Timer t) {
		logger.info("@Schedule in scheduledTimeout() called at: " + new java.util.Date());
    }
}